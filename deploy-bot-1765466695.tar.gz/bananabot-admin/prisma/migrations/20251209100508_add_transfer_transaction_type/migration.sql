-- AlterEnum
ALTER TYPE "TransactionType" ADD VALUE 'TRANSFER';
