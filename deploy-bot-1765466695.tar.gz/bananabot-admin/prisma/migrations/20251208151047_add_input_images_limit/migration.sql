-- AlterTable
ALTER TABLE "ModelTariff" ADD COLUMN     "inputImagesLimit" INTEGER NOT NULL DEFAULT 5;
