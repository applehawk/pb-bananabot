-- AlterTable
ALTER TABLE "SystemSettings" ADD COLUMN     "defaultNewUserModelId" TEXT NOT NULL DEFAULT 'gemini-2.5-flash-image';
