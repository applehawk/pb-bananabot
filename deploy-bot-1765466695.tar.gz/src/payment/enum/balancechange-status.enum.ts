export enum BalanceChangeStatusEnum {
  DONE = 'DONE',
  INSUFFICIENT = 'INSUFFICIENT',
}
