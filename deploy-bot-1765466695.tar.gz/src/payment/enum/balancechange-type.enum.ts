export enum BalanceChangeTypeEnum {
  PAYMENT = 'PAYMENT',
  MANUALLY = 'MANUALLY',
  SCHEDULER = 'SCHEDULER',
}
