# BananaBot Admin Panel

Административная панель для управления Telegram-ботом BananaBot. Построена на [Next.js](https://nextjs.org) с использованием App Router.

## Функциональность

- 📊 **Аналитика** - просмотр статистики использования бота
- 👥 **Управление пользователями** - просмотр и редактирование пользователей
- 🎨 **Генерации** - история генераций изображений
- 💰 **Транзакции** - управление платежами и подписками
- 📦 **Пакеты** - настройка тарифных планов
- 🔐 **Админ-пользователи** - управление доступом к админ-панели

## Быстрый старт

### Установка зависимостей

```bash
make install
# или
pnpm install
```

### Настройка окружения

Создайте файл `.env` на основе `.env.example`:

```bash
cp .env.example .env
```

### Запуск в режиме разработки

```bash
make dev
# или
pnpm dev
```

Откройте [http://localhost:3001](http://localhost:3001) в браузере.

### Сборка для продакшена

```bash
make build
# или
pnpm build
```

### Запуск в продакшене

```bash
make start
# или
pnpm start
```

## Доступные команды

Используйте `make help` для просмотра всех доступных команд:

```bash
make help
```

## Технологический стек

- **Framework:** Next.js 15 (App Router)
- **Styling:** Tailwind CSS
- **Database:** Prisma ORM
- **Package Manager:** pnpm
- **TypeScript:** Full type safety

## Структура проекта

```
bananabot-admin/
├── app/                    # Next.js App Router
│   ├── admin-users/       # Управление админами
│   ├── analytics/         # Аналитика
│   ├── api/               # API маршруты
│   ├── generations/       # История генераций
│   ├── transactions/      # Транзакции
│   └── users/             # Управление пользователями
├── components/            # React компоненты
├── lib/                   # Утилиты и хелперы
├── public/                # Статические файлы
└── scripts/               # Скрипты (например, seed)
```

## Deployment

### Amvera Cloud

Репозиторий настроен для деплоя на Amvera Cloud:

```bash
git push amvera main
```

### Vercel

Также можно задеплоить на [Vercel Platform](https://vercel.com/new):

1. Импортируйте репозиторий в Vercel
2. Настройте переменные окружения
3. Деплой произойдет автоматически

## Связь с основным проектом

Этот репозиторий является git submodule основного репозитория BananaBot:
- **Основной репозиторий:** [applehawk/pb-bananabot](https://github.com/applehawk/pb-bananabot)

## Ресурсы

- [Next.js Documentation](https://nextjs.org/docs)
- [Prisma Documentation](https://www.prisma.io/docs)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
