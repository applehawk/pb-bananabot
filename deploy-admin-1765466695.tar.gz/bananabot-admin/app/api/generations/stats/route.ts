import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { handleDatabaseError } from '@/lib/db-error-handler';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
    try {
        const { searchParams } = new URL(request.url);
        const userId = searchParams.get('userId');
        const type = searchParams.get('type');
        const status = searchParams.get('status'); // 'ALL' or specific status
        const scale = searchParams.get('scale') || '1M'; // '1D', '1W', '1M', '1Q'

        const where: any = {};
        if (userId) where.userId = userId;
        if (type) where.type = type;
        if (status && status !== 'ALL') {
            where.status = status;
        }

        // 1. Calculate Period Stats (1d, 7d, 30d, 90d)
        const now = new Date();
        const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        const ninetyDaysAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);

        const [count1d, count7d, count30d, count90d] = await Promise.all([
            prisma.generation.count({ where: { ...where, createdAt: { gte: oneDayAgo } } }),
            prisma.generation.count({ where: { ...where, createdAt: { gte: sevenDaysAgo } } }),
            prisma.generation.count({ where: { ...where, createdAt: { gte: thirtyDaysAgo } } }),
            prisma.generation.count({ where: { ...where, createdAt: { gte: ninetyDaysAgo } } }),
        ]);

        // 2. Calculate Chart Stats based on 'scale'
        let chartStartDate = thirtyDaysAgo;
        let bucketSize = 'day'; // 'hour', '6hour', 'day'

        if (scale === '1D') {
            chartStartDate = oneDayAgo;
            bucketSize = 'hour';
        } else if (scale === '1W') {
            chartStartDate = sevenDaysAgo;
            bucketSize = '6hour';
        } else if (scale === '1M') {
            chartStartDate = thirtyDaysAgo;
            bucketSize = 'day';
        } else if (scale === '1Q') {
            chartStartDate = ninetyDaysAgo;
            bucketSize = 'day';
        }

        // Fetch basic data for aggregation
        // Optimization: For 1Q/1M we only need dates.
        const statsData = await prisma.generation.findMany({
            where: {
                ...where,
                createdAt: { gte: chartStartDate }
            },
            select: {
                createdAt: true
            }
        });

        // 3. Generate Chart Data
        const chartStats = generateChartData(statsData, chartStartDate, now, bucketSize);

        return NextResponse.json({
            periodStats: {
                day1: count1d,
                day7: count7d,
                day30: count30d,
                day90: count90d
            },
            dailyStats: chartStats // Retaining key name 'dailyStats' for backward compatibility or updating frontend to use it
        });

    } catch (error) {
        console.error('Error fetching stats:', error);
        const errorResponse = handleDatabaseError(error);
        return NextResponse.json(errorResponse, { status: errorResponse.status });
    }
}

function getStep(bucketSize: string): number {
    switch (bucketSize) {
        case 'hour': return 60 * 60 * 1000;
        case '6hour': return 6 * 60 * 60 * 1000;
        case 'day': return 24 * 60 * 60 * 1000;
        default: return 24 * 60 * 60 * 1000;
    }
}

function generateChartData(
    data: { createdAt: Date }[],
    start: Date,
    end: Date,
    bucketSize: string
) {
    const map = new Map<string, number>();
    const formatKey = (date: Date) => {
        if (bucketSize === 'day') return date.toISOString().split('T')[0];

        const d = new Date(date);
        d.setMinutes(0);
        d.setSeconds(0);
        d.setMilliseconds(0);

        if (bucketSize === '6hour') {
            const h = d.getHours();
            const roundedH = Math.floor(h / 6) * 6;
            d.setHours(roundedH);
        }

        return d.toISOString();
    };

    // Initialize buckets
    let current = new Date(start);
    if (bucketSize === 'hour') {
        current.setMinutes(0, 0, 0);
    } else if (bucketSize === '6hour') {
        current.setMinutes(0, 0, 0);
        const h = current.getHours();
        current.setHours(Math.floor(h / 6) * 6);
    }

    while (current <= end) {
        map.set(formatKey(current), 0);
        current = new Date(current.getTime() + getStep(bucketSize));
    }

    // Fill data
    data.forEach(item => {
        const key = formatKey(new Date(item.createdAt));
        if (map.has(key)) {
            map.set(key, (map.get(key) || 0) + 1);
        } else {
            map.set(key, (map.get(key) || 0) + 1);
        }
    });

    return Array.from(map.entries())
        .map(([date, count]) => ({ date, count }))
        .sort((a, b) => a.date.localeCompare(b.date));
}
