-- AlterTable
ALTER TABLE "ModelTariff" ADD COLUMN     "inputImageTokens" INTEGER;
