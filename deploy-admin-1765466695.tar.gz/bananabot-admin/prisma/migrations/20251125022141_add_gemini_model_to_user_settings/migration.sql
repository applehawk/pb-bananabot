-- AlterTable
ALTER TABLE "UserSettings" ADD COLUMN "geminiModel" TEXT NOT NULL DEFAULT 'gemini-2.5-flash-image';
