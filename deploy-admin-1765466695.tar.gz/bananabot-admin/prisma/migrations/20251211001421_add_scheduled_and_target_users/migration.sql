-- AlterTable
ALTER TABLE "Broadcast" ADD COLUMN     "targetUserIds" TEXT[];
