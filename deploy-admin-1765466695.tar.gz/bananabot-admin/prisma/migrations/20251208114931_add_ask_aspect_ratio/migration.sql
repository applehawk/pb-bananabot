-- AlterTable
ALTER TABLE "UserSettings" ADD COLUMN     "askAspectRatio" BOOLEAN NOT NULL DEFAULT false;
