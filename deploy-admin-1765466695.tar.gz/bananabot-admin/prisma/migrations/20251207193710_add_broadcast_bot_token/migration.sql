-- AlterTable
ALTER TABLE "Broadcast" ADD COLUMN     "botToken" TEXT;
